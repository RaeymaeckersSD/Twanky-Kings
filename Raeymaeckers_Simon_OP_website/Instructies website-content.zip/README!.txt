Readme 

instructies voor content op website

1. uitleg foto's

-de photoframe1.jpg openen in photoshop of illustrator zal u het exacte formaat geven van de foto zelf.
-foto's kunnen info(advertenties?) zijn van eventuele festivals en/of sponsors en artiesten(onze fictieve artiesten & misschien bestaande artiesten).
-voor de webwinkel foto's kleding en eventuele andere snuisterijen(platen,...?). 
-op de foto's rechts vanonder(of waar jezelf wilt) tekst plaatsen zodat je weet waarover het gaat(bv. speciale T-shirt 10�/Bezoek ook deze evenement).
-mischien een kaart met ons hoofdkantoor voor in de contact-page

2. uitleg tekst

-Als het al kan tekst schrijven over onze platenmaatschappij voor in de about-page te steken.
-tekst voor evenementen-page(kan tekst van affiche of flyer zijn).
-tekst voor Contact-page(adres gegevens)

-(deze lijst kan misschien nog een update krijgen).
 
